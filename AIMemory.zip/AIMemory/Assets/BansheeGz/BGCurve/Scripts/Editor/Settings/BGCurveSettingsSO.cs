﻿using System;
using BansheeGz.BGSpline.Curve;
using UnityEngine;

namespace BansheeGz.BGSpline.Editor
{
    [Serializable]
    public class BGCurveSettingsSO : ScriptableObject
    {
        public BGCurveSettings Settings;
    }
}